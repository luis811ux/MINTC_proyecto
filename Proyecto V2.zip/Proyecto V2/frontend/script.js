const apiUrl = 'http://localhost:3000/suscriptores';

document.addEventListener('DOMContentLoaded', cargarSuscriptores);

async function cargarSuscriptores() {
    const response = await fetch(apiUrl);
    const suscriptores = await response.json();
    const tbody = document.querySelector('#suscriptoresTable tbody');
    tbody.innerHTML = '';

    suscriptores.forEach(suscriptor => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${suscriptor.id}</td>
            <td><input type="text" value="${suscriptor.nombre}" id="nombre-${suscriptor.id}"></td>
            <td><input type="number" value="${suscriptor.cedula}" id="cedula-${suscriptor.id}"></td>
            <td><input type="email" value="${suscriptor.email}" id="email-${suscriptor.id}"></td>
            <td><input type="text" value="${suscriptor.curso}" id="curso-${suscriptor.id}"></td>
            <td>
                <img src="http://localhost:5500/uploads/${suscriptor.imagen}" alt="Imagen" style="max-width: 150px; height: auto;">
            </td>
            <td>
                <input type="file" id="imagen-${suscriptor.id}"> <!-- Campo para nueva imagen -->
                <p></p>
                <button onclick="actualizarSuscriptor(${suscriptor.id})">Actualizar</button>
                <button onclick="eliminarSuscriptor(${suscriptor.id})">Eliminar</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
    
}

// Función para agregar un nuevo suscriptor
document.querySelector('#suscriptorForm').addEventListener('submit', async (e) => {
    e.preventDefault(); // Evitamos que el formulario recargue la página
    const nombre = document.getElementById('nombre').value;
    const cedula = document.getElementById('cedula').value;
    const email = document.getElementById('email').value;
    const curso = document.getElementById('curso').value;
    const imagen = document.getElementById('imagen').files[0]; // Obtenemos la imagen

    const formData = new FormData();
    formData.append('nombre', nombre);
    formData.append('cedula', cedula);
    formData.append('email', email);
    formData.append('curso', curso);
    formData.append('imagen', imagen); // Añadimos la imagen al FormData

    // Hacemos la solicitud POST para crear un suscriptor con imagen
    const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData, // Enviamos el FormData
    });

    if (response.ok) {
        alert('Suscriptor agregado con éxito');
        cargarProductos(); // Recargamos la lista de suscriptores
    } else {
        alert('Error al agregar el suscriptor');
    }
});

async function actualizarSuscriptor(id) {
    // Obtener los valores actualizados de los campos
    const nombre = document.getElementById(`nombre-${id}`).value;
    const cedula = document.getElementById(`cedula-${id}`).value;
    const email = document.getElementById(`email-${id}`).value;
    const curso = document.getElementById(`curso-${id}`).value;
    const imagen = document.getElementById(`imagen-${id}`) ? document.getElementById(`imagen-${id}`).files[0] : null; // Obtiene la nueva imagen si está presente

    // Validar que se ingresen valores válidos
    if (!nombre || !cedula|| !email || !curso) {
        alert('Por favor, ingresa un nombre y un precio válidos');
        return;
    }

    
    

    const formData = new FormData();
    formData.append('nombre', nombre);
    formData.append('cedula', cedula);
    formData.append('email', email);
    formData.append('curso', curso);
    


    if (imagen) {
        formData.append('imagen', imagen); // Añadir nueva imagen si existe
    }

    // Enviar la solicitud PUT al backend
    const response = await fetch(`http://localhost:3000/suscriptores/${id}`, {
        method: 'PUT',
        body: formData,
    });

    if (response.ok) {
        alert('Suscriptor actualizado');
        cargarProductos();  // Volver a cargar la lista de suscriptores
    } else {
        alert('Error al actualizar el suscriptor');
    }
}



async function eliminarSuscriptor(id) {
    const response = await fetch(`${apiUrl}/${id}`, {
        method: 'DELETE'
    });

    if (response.ok) {
        alert('Suscriptor eliminado');
        cargarProductos(); // Recargamos la lista de suscriptores
    } else {
        alert('Error al eliminar el suscriptor');
    }
}
