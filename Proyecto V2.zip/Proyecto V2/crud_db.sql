CREATE DATABASE crud_db;
USE crud_db;

CREATE TABLE suscriptores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    cedula VARCHAR(15) NOT NULL,    
    email VARCHAR(50) NOT NULL,
    curso VARCHAR(100) NOT NULL,
    imagen VARCHAR(255) DEFAULT NULL
);

select * from suscriptores;

INSERT INTO suscriptores (nombre, cedula, email, curso, imagen) 
VALUES ("Luis Alcala", "80187811", "luis@gmail.com", "Full Stack", "C:\Users\DELL\Documents\PROGRAMACION\MINTIC\MODULO BASICO\PROYECTO PAGINA WEB APRENDER PROGRAMCION\CRUD\proyecto-crud - imagen\uploads\1731855467510.jpg");

DELETE FROM suscriptores WHERE id = 4;



DROP DATABASE crud_db;
